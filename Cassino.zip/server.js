const express = require("express");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const db = new Database("database.db");

// ===============================
// BANCO DE DADOS
// ===============================

db.exec(`
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    balance INTEGER NOT NULL DEFAULT 1000
);

CREATE TABLE IF NOT EXISTS spins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    result TEXT NOT NULL,
    bet INTEGER NOT NULL,
    win INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
`);

// ===============================
// JOGO
// ===============================

const symbols = [
    { icon: "🐯", multiplier: 10 },
    { icon: "💎", multiplier: 8 },
    { icon: "⭐", multiplier: 6 },
    { icon: "🍀", multiplier: 5 },
    { icon: "🍊", multiplier: 3 }
];

const BET = 10;

function randomSymbol() {
    return symbols[Math.floor(Math.random() * symbols.length)];
}

function calculateWin(result) {

    let win = 0;

    const lines = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8]
    ];

    for (const line of lines) {

        const a = result[line[0]];
        const b = result[line[1]];
        const c = result[line[2]];

        if (a === b && b === c) {

            const symbol =
                symbols.find(s => s.icon === a);

            win += BET * symbol.multiplier;

        } else if (
            a === b ||
            b === c ||
            a === c
        ) {

            win += Math.floor(BET * 1.5);
        }
    }

    return win;
}

// ===============================
// CRIAR USUÁRIO
// ===============================

app.post("/api/register", (req, res) => {

    const { username } = req.body;

    if (!username) {
        return res.status(400).json({
            error: "Digite um nome."
        });
    }

    try {

        const result = db.prepare(`
            INSERT INTO users (username, balance)
            VALUES (?, 1000)
        `).run(username);

        res.json({
            success: true,
            userId: result.lastInsertRowid,
            username,
            balance: 1000
        });

    } catch {

        res.status(400).json({
            error: "Esse usuário já existe."
        });
    }
});

// ===============================
// CONSULTAR SALDO
// ===============================

app.get("/api/user/:id", (req, res) => {

    const user = db.prepare(`
        SELECT id, username, balance
        FROM users
        WHERE id = ?
    `).get(req.params.id);

    if (!user) {
        return res.status(404).json({
            error: "Usuário não encontrado."
        });
    }

    res.json(user);
});

// ===============================
// GIRAR
// ===============================

app.post("/api/spin", (req, res) => {

    const { userId } = req.body;

    const user = db.prepare(`
        SELECT *
        FROM users
        WHERE id = ?
    `).get(userId);

    if (!user) {
        return res.status(404).json({
            error: "Usuário não encontrado."
        });
    }

    if (user.balance < BET) {
        return res.status(400).json({
            error: "Saldo virtual insuficiente."
        });
    }

    // Cobra a rodada
    db.prepare(`
        UPDATE users
        SET balance = balance - ?
        WHERE id = ?
    `).run(BET, userId);

    // Resultado
    const result = Array.from(
        { length: 9 },
        () => randomSymbol().icon
    );

    const win = calculateWin(result);

    // Adiciona prêmio
    if (win > 0) {

        db.prepare(`
            UPDATE users
            SET balance = balance + ?
            WHERE id = ?
        `).run(win, userId);
    }

    const updatedUser = db.prepare(`
        SELECT balance
        FROM users
        WHERE id = ?
    `).get(userId);

    db.prepare(`
        INSERT INTO spins
        (user_id, result, bet, win)
        VALUES (?, ?, ?, ?)
    `).run(
        userId,
        JSON.stringify(result),
        BET,
        win
    );

    res.json({
        success: true,
        result,
        bet: BET,
        win,
        balance: updatedUser.balance
    });
});

// ===============================
// HISTÓRICO
// ===============================

app.get("/api/history/:userId", (req, res) => {

    const history = db.prepare(`
        SELECT
            id,
            result,
            bet,
            win,
            created_at
        FROM spins
        WHERE user_id = ?
        ORDER BY id DESC
        LIMIT 20
    `).all(req.params.userId);

    history.forEach(item => {
        item.result = JSON.parse(item.result);
    });

    res.json(history);
});

// ===============================
// RESETAR CONTA
// ===============================

app.post("/api/reset/:userId", (req, res) => {

    db.prepare(`
        UPDATE users
        SET balance = 1000
        WHERE id = ?
    `).run(req.params.userId);

    res.json({
        success: true,
        balance: 1000
    });
});

// ===============================
// SERVIDOR
// ===============================

app.listen(PORT, () => {

    console.log("");
    console.log("🐯 TIGRE PLATFORM DEMO");
    console.log(`Servidor: http://localhost:${PORT}`);
    console.log("");
});